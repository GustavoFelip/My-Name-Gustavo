<h1>Olá Tudo Bem com você ?!</h1>

 <div>
  <a href="https://github.com/GustavoFelip">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=GustavoFelip&show_icons=true&theme=midnight-purple&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=GustavoFelip&layout=compact&langs_count=7&theme=midnight-purple"/>
</div>
  
  <div style="display: inline_block"><br>
  <img align="center" alt="Gu-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Gu-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="Gu-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Rafa-Php" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg">
  </div>
 
 ## <div>
   ![Snake animation](https://github.com/gustavofelip/gustavofelip/blob/output/github-contribution-grid-snake.svg)
 </div>
